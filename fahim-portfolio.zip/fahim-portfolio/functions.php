<?php
/**
 * Theme setup
 */
function fahim_portfolio_setup() {
  add_theme_support( 'post-thumbnails' );
  add_theme_support( 'responsive-embeds' );
  add_theme_support( 'editor-styles' );
  add_theme_support( 'wp-block-styles' );
  register_nav_menus( array(
    'primary' => __( 'Primary Menu', 'fahim-portfolio' ),
    'footer'  => __( 'Footer Menu', 'fahim-portfolio' ),
  ) );
}
add_action( 'after_setup_theme', 'fahim_portfolio_setup' );

/**
 * Enqueue fonts
 */
function fahim_portfolio_assets() {
  wp_enqueue_style( 'fahim-portfolio-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap', array(), null );
}
add_action( 'wp_enqueue_scripts', 'fahim_portfolio_assets' );
add_action( 'enqueue_block_editor_assets', 'fahim_portfolio_assets' );

/**
 * Register Project CPT + Skill taxonomy
 */
function fahim_portfolio_cpt() {
  $labels = array(
    'name' => 'Projects',
    'singular_name' => 'Project',
  );
  register_post_type( 'project', array(
    'labels' => $labels,
    'public' => true,
    'menu_icon' => 'dashicons-portfolio',
    'supports' => array( 'title','editor','thumbnail','excerpt','revisions' ),
    'has_archive' => true,
    'show_in_rest' => true,
  ) );
  register_taxonomy( 'skill', 'project', array(
    'label' => 'Skills',
    'public' => true,
    'hierarchical' => false,
    'show_in_rest' => true,
  ) );
}
add_action( 'init', 'fahim_portfolio_cpt' );

/**
 * Helper: CV download endpoint (place your CV at /wp-content/uploads/cv.pdf)
 */
add_action('rest_api_init', function() {
  register_rest_route('fahim/v1','/cv', array(
    'methods'=>'GET',
    'callback'=>function() {
      $cv = wp_upload_dir()['basedir'] . '/cv.pdf';
      if ( file_exists( $cv ) ) {
        return rest_ensure_response( array( 'url' => wp_upload_dir()['baseurl'] . '/cv.pdf' ) );
      }
      return new WP_Error('no_cv','CV not found', array('status'=>404));
    }
  ));
});