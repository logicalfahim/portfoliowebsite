<?php
/**
 * Title: Education Cards
 * Slug: fahim-portfolio/education-cards
 * Categories: featured
 */
?>
<!-- wp:group {"layout":{"type":"constrained","contentSize":"1200px"}} -->
<div class="wp-block-group">
<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Education</h3>
<!-- /wp:heading -->
<!-- wp:columns -->
<div class="wp-block-columns">
  <!-- wp:column -->
  <div class="wp-block-column"><div class="card">
    <!-- wp:heading {"level":4} --><h4 class="wp-block-heading">BSc in CSE</h4><!-- /wp:heading -->
    <!-- wp:paragraph --> <p>University Name</p> <!-- /wp:paragraph -->
  </div></div>
  <!-- /wp:column -->
  <!-- wp:column -->
  <div class="wp-block-column"><div class="card">
    <!-- wp:heading {"level":4} --><h4 class="wp-block-heading">Training</h4><!-- /wp:heading -->
    <!-- wp:paragraph --> <p>WordPress / PHP</p> <!-- /wp:paragraph -->
  </div></div>
  <!-- /wp:column -->
  <!-- wp:column -->
  <div class="wp-block-column"><div class="card">
    <!-- wp:heading {"level":4} --><h4 class="wp-block-heading">Certifications</h4><!-- /wp:heading -->
    <!-- wp:paragraph --> <p>Google, Meta, etc.</p> <!-- /wp:paragraph -->
  </div></div>
  <!-- /wp:column -->
</div>
<!-- /wp:columns -->
</div>
<!-- /wp:group -->