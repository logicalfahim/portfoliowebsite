<?php
/**
 * Title: Hero Profile
 * Slug: fahim-portfolio/hero-profile
 * Categories: banner, featured
 */
?>
<!-- wp:group {"className":"hero-gradient","layout":{"type":"constrained"}} -->
<div class="wp-block-group hero-gradient">
  <!-- wp:group {"className":"app-surface","layout":{"type":"constrained","contentSize":"1200px"}} -->
  <div class="wp-block-group app-surface">
    <!-- wp:group {"style":{"spacing":{"padding":{"top":"40px","right":"40px","bottom":"40px","left":"40px"}}},"layout":{"type":"flex","verticalAlignment":"top","justifyContent":"space-between"}} -->
    <div class="wp-block-group" style="padding-top:40px;padding-right:40px;padding-bottom:40px;padding-left:40px">
      <!-- wp:group {"layout":{"type":"constrained","contentSize":"480px"}} -->
      <div class="wp-block-group">
        <!-- wp:image {"id":1,"sizeSlug":"full","linkDestination":"none","className":"profile-pic"} -->
        <figure class="wp-block-image size-full profile-pic"><img src="https://placehold.co/264x264/png" alt="Profile"/></figure>
        <!-- /wp:image -->
        <!-- wp:heading {"level":1,"fontSize":"4xl"} -->
        <h1 class="wp-block-heading has-4-xl-font-size">Fahim Hossain</h1>
        <!-- /wp:heading -->
        <!-- wp:paragraph {"fontSize":"sm"} -->
        <p class="has-sm-font-size">(he/him)</p>
        <!-- /wp:paragraph -->
        <!-- wp:paragraph {"style":{"typography":{"fontStyle":"normal","fontWeight":"600"}},"textColor":"primary"} -->
        <p class="has-primary-color has-text-color" style="font-style:normal;font-weight:600">WordPress Developer</p>
        <!-- /wp:paragraph -->
        <!-- wp:social-links {"iconColor":"ink","iconColorValue":"#0f172a","size":"has-normal-icon-size","style":{"spacing":{"blockGap":{"top":"12px","left":"12px"}}}} -->
        <ul class="wp-block-social-links has-normal-icon-size has-icon-color">
          <!-- wp:social-link {"service":"github"} /-->
          <!-- wp:social-link {"service":"linkedin"} /-->
          <!-- wp:social-link {"service":"wordpress"} /-->
          <!-- wp:social-link {"service":"dribbble"} /-->
        </ul>
        <!-- /wp:social-links -->
      </div>
      <!-- /wp:group -->

      <!-- wp:group {"layout":{"type":"constrained","contentSize":"620px"}} -->
      <div class="wp-block-group">
        <!-- wp:heading {"level":3} -->
        <h3 class="wp-block-heading">Professional Summary</h3>
        <!-- /wp:heading -->
        <!-- wp:paragraph -->
        <p>I build fast, accessible WordPress websites and plugins. I specialize in block themes, WooCommerce, custom Gutenberg blocks, and scalable hosting setups. Below is a selection of my work, skills, and writing.</p>
        <!-- /wp:paragraph -->
        <!-- wp:buttons -->
        <div class="wp-block-buttons">
          <!-- wp:button {"backgroundColor":"primary","textColor":"white","className":"btn-primary"} -->
          <div class="wp-block-button btn-primary"><a class="wp-block-button__link has-white-color has-primary-background-color has-text-color has-background wp-element-button" href="/wp-json/fahim/v1/cv" target="_blank" rel="noreferrer noopener">Download CV</a></div>
          <!-- /wp:button -->
        </div>
        <!-- /wp:buttons -->
      </div>
      <!-- /wp:group -->
    </div>
    <!-- /wp:group -->
  </div>
  <!-- /wp:group -->
</div>
<!-- /wp:group -->