<?php
/**
 * Title: Projects Grid
 * Slug: fahim-portfolio/projects-grid
 * Categories: portfolio, query
 */
?>
<!-- wp:group {"layout":{"type":"constrained","contentSize":"1200px"}} -->
<div class="wp-block-group">
<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Selected Projects</h3>
<!-- /wp:heading -->
<!-- wp:query {"queryId":1,"query":{"perPage":9,"pages":0,"offset":0,"postType":"project","order":"desc","orderBy":"date"},"displayLayout":{"type":"grid","columns":3},"className":"projects-grid"} -->
<div class="wp-block-query projects-grid">
  <!-- wp:post-template -->
    <!-- wp:group {"className":"card is-glass"} -->
    <div class="wp-block-group card is-glass">
      <!-- wp:post-featured-image {"isLink":true} /-->
      <!-- wp:post-title {"isLink":true,"level":4} /-->
      <!-- wp:post-excerpt {"moreText":"View case study →"} /-->
      <!-- wp:post-terms {"term":"skill","prefix":"Skills: "} /-->
    </div>
    <!-- /wp:group -->
  <!-- /wp:post-template -->
</div>
<!-- /wp:query -->
</div>
<!-- /wp:group -->